
import type { Product } from './types';

export const INITIAL_PRODUCTS: Product[] = [];
